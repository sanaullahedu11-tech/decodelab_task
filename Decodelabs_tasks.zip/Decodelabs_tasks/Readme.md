# Project 1: Linux & Command Line Basics

## Industrial Training
**Batch:** 2026  
**Organization:** DecodeLabs

## Objective
The objective of this project is to learn the fundamentals of Linux and become familiar with the Linux command line, which is an essential skill for every DevOps Engineer.

## Topics Covered
- Linux directory structure
- File and directory management
- Basic Linux commands
- File permissions
- Navigation using the terminal

## Commands Practiced
- pwd
- ls
- cd
- mkdir
- touch
- cat
- cp
- mv
- rm
- chmod

## What I Learned
Through this project, I learned how to:
- Navigate the Linux file system.
- Create, rename, copy, move, and delete files and directories.
- Display file contents using the terminal.
- Manage file permissions using `chmod`.
- Work efficiently using Linux command-line tools.

## Screenshots
Screenshots of all completed tasks are available in the `screenshots` folder.

## Author
**Sana Ullah**
BS Computer Science
DevOps Intern – DecodeLabs
Your GitHub repository should look like this:
decodelabs_tasks/
│
├── Project-1/
│   ├── README.md
│   └── screenshots/
│       ├── 01_pwd.png
│       ├── 02_ls.png
│       ├── 03_mkdir.png
│       ├── 04_touch.png
│       ├── 05_cat.png
│       ├── 06_cp.png
│       ├── 07_mv.png
│       ├── 08_rm.png
│       └── 09_chmod.png