# Project 3 CICD Pipeline Basics

## Objective

This project demonstrates a basic CICD workflow using GitHub Actions. The pipeline automatically runs whenever code is pushed to the `main` branch.

## Technologies Used

 Git
 GitHub
 GitHub Actions
 HTML

## Pipeline Stages

1. Checkout Code – Downloads the repository files.
2. List Files – Displays project contents.
3. Verify Build – Checks whether `index.html` exists.

## Workflow File

`.githubworkflowsci.yml`

## Outcome

After pushing the code to GitHub, the workflow runs automatically and validates the project structure successfully.

## Author

Sana Ullah
DevOps Intern – DecodeLabs
