# Project 2: Version Control with Git

## Industrial Training
**Batch:** 2026  
**Organization:** DecodeLabs

## Objective
The objective of this project is to learn the fundamentals of Git and GitHub for version control. Git helps developers track changes, collaborate with teams, and maintain project history efficiently.

## Topics Covered
- Git initialization
- Repository management
- Staging files
- Creating commits
- Viewing repository status
- Connecting to GitHub
- Pushing code to a remote repository

## Git Commands Practiced
- git init
- git status
- git add .
- git commit -m "Initial commit"
- git log --oneline
- git remote add origin
- git branch -M master
- git push -u origin master

## What I Learned
Through this project, I learned how to:
- Initialize a Git repository.
- Track files using Git.
- Stage and commit changes.
- View commit history.
- Connect a local repository to GitHub.
- Push project files to a remote repository.

## Repository
GitHub Repository:
https://github.com/YourUsername/decodelabs_tasks

## Screenshots
Screenshots demonstrating each Git command are available in the `screenshots` folder.

## Author
**Sana Ullah**  
BS Computer Science  
DevOps Intern – DecodeLabs